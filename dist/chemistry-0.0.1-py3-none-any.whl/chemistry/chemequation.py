from collections import namedtuple

EquationRoot = namedtuple('equation_root', 'equation reactants products')

def parse_equation(equation: str):
    pass

